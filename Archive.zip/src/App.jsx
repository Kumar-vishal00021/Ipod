import React,{Component} from "react";
import Ipod from "./component/Ipod";
export default class App extends Component{

    render(){
      return(
        <>
          <Ipod />
        </>
      )
    }
}
