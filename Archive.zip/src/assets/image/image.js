import coreMenuImg from "./coreMenu.jpg";
import settings from './Apple_Settings-512.webp';
import games from './games.jpg';
import coverFlow from './coverFlow.jpeg'
const images = {
    coreMenuImg,
    games,
    settings,
    coverFlow
}

export default images;