import audio1 from "./_One_Bottle_Down__FULL_VIDEO_SONG___Yo_Yo_Honey_Singh___T-SERIES(256k).mp3"
import audio2 from "./Achko_Machko_-_Yo_Yo_Honey_Singh_-_Brand_New_Song_2016(256k).mp3"
import audio3 from "./Designer__Full_Video__Guru_Randhawa%2C_Yo_Yo_Honey_Singh_Ft._Divya_Khosla_Kumar___Mihir_G___Bhushan_K(256k).mp3"
import audio4 from "./Mercy_-_Badshah_Feat._Lauren_Gottlieb___Official_Music_Video___Latest_Hit_Song_2017(256k).mp3"
import audio1Img from '../image/one-Bottle-Down.jpeg';
import audio2Img from '../image/achko-machko.jpeg';
import audio3Img from '../image/designer.jpeg';
import audio4Img from '../image/mercy.jpeg';

const songs = {
    0:{audio:audio1 , img:audio1Img ,title:"One Bottle Down",singer:"Yo-Yo"},
    1:{audio:audio2 , img:audio2Img,title:"Achko machko",singer:"Yo-Yo"},
    2:{audio:audio3 , img:audio3Img,title:"Designer",singer:"Yo-Yo"},
    3:{audio:audio4 , img:audio4Img,title:"Mercy",singer:"Yo-Yo"},
}
export default songs;