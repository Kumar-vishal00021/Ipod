import React from "react";
import images from "../../assets/image/image";
export default function Games() {
   return(
    <div  className="screenContainer">
        <img src={images.games} className="screenImg" alt=""/>
    </div>
   )
}