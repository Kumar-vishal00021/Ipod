import React from "react";
import images from "../../assets/image/image";
export default function CoverFlow() {
   return(
    <div  className="screenContainer">
        <img src={images.coverFlow} className="screenImg" alt=""/>
    </div>
   )
}