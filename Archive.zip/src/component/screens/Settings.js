import React from "react";
import images from "../../assets/image/image";
export default function Settings() {
   return(
    <div  className="screenContainer">
        <img src={images.settings} className="screenImg" alt=""/>
    </div>
   )
}